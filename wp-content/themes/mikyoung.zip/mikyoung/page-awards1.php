<?php
/* 
Template Name: Awards
*/
?><?php get_header();?>

<?php while ( have_posts() ) : the_post(); ?>

	<div class="container work page-body page-container loading loaded">

		<div class="row">
		
			
			
			<div class="col-sm-12 " id="award-content">
				<div class="page-content ">
					
					

					<section class="about-section" id="about_awards">
						<h3 class="section-heading bg-brand">Awards</h3>						
						<h3 class="section-intro"><?php the_field('awards_introduction','option'); ?></h3>						
						<div class="section-body row">
							<div class="col-sm-12">
								<ul class="awards-list">
									<?php 
									$ac = 1;
									while(has_sub_field('awards','option')): 
									?>
										<li class="<?php if($ac >= 9): echo 'awards-trim '; endif; ?>">
										<img src="<?php the_sub_field('award_icon'); ?>" />
<span class="bold"><?php the_sub_field('award_year','option'); ?> </span> <?php the_sub_field('award_description','option'); ?></li>
									<?php 
									$ac = $ac+1;
									endwhile; ?>
								</ul>
								<?php if($ac >= 9):  ?>
									<a href="#" id="awards-expand" class="bg-brand">show all awards +</a>
								<?php endif; ?>
							</div>					
						</div>
					</section>	
					
					
																					
								
				</div>
			</div>		
										
		</div>
		
	</div>	
		

		


<?php endwhile; ?>

<?php get_footer();?>
