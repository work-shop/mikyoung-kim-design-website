<?php
/* 
Template Name: Work
*/
?><?php get_header(); ?>

<?php get_template_part('work'); ?>

<?php get_footer();?>
