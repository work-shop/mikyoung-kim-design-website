<?php get_header();?>

	<?php get_template_part('project'); ?>

<?php get_footer();?>
