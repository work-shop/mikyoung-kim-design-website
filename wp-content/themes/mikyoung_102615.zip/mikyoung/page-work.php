<?php get_header(); ?>

<?php get_template_part('work'); ?>

<?php get_footer();?>
