<?php get_header();?>

	<div class="row page-404">
		
		<div class="col-sm-8 col-sm-offset-2 brand">	
			<h2 class="">Oh No! Looks like the page you're looking for isn't here anymore. Sorry about that! Try heading back to our <a href="<?php bloginfo('site_url'); ?>">Home Page.</a></h2>
		</div>	
	
	</div>

<?php get_footer();?>

