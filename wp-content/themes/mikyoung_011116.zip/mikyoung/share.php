<div id="share" class="share row">

	<div class="col-center">
		
		<h2 class="">Share</h2>
		
		<div class="centered">
			<a class="addthis_button_facebook"><span class="icon social " data-icon="F"></span></a>
			<a class="addthis_button_twitter"><span class="icon social " data-icon="t"></span></a>
			<a class="addthis_button_email"><span class="icon social " data-icon="m"></span></a>
		</div>	
		
	</div>	

</div>		


		

		
